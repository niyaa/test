python-mesh-scripts
===================

some random script to help convert meshes
